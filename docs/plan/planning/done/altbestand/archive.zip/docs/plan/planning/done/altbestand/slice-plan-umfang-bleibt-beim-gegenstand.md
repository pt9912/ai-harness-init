# Slice slice-plan-umfang-bleibt-beim-gegenstand: Der Plan-Umfang bleibt beim Gegenstand

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** ohne Welle. (1) Bündel? Nein. (2) Gemeinsames Closure-Kriterium? Nein.
(3) **Reaktiv:** eine Register-Beobachtung über der Schwelle. Begründet gegen die drei Fragen aus
[`MR-016`](../../../../harness/conventions.md#mr-016--welle-oder-nicht-und-wo-wellenlose-arbeit-geführt-wird).

**Bezug:** Baseline-Regelwerk `modul-05-planning-harness.md` §Ziel-Form: Slice (Zu-groß-Kriterien,
Ein-Sitzungs-Review), [`MR-057`](../../../../harness/conventions.md#mr-057--die-kennungs-form-für-neue-slices-und-wellen-ist-der-name-nicht-die-nummer),
[`AGENTS.md`](../../../../AGENTS.md) §3.7 (die Stelle beschreiben, nicht den Vorgang ihrer
Entstehung).

**Berührte Spec-Stellen:** `—`.

**Verantwortlich:** — bis zur Priorisierung.

**Autor:** Planner. **Datum:** 2026-09-14.

---

## 1. Ziel und Abgrenzung

**Ziel:** Die Regel, dass ein Slice-Plan nur trägt, was der Slice trägt, nennt eine messbare Form
und ihre Grenze. Die Regel selbst steht seit `ca5fce63` in `.claude/agents/planner.md` (*Knapp
schreiben*) und `.claude/commands/plan-welle.md` (*Plan knapp halten*); offen ist, woran ihr
Bruch erkennbar ist.

Die Größen-Regel des Baseline-Regelwerks deckelt **Liefer-Punkte**
und die Reviewbarkeit in einer Sitzung, nicht den Umfang der Herleitung. Ein Slice-Plan dieses Repos
trägt ein Vielfaches der Zeilenzahl, die das Schwester-Repo für dieselbe Arbeitsklasse braucht.
Beleg:
[`BEO-ALL/slice-plan-umfang-waechst-ueber-umsetzung-hinaus`](../observations/BEO-ALL/slice-plan-umfang-waechst-ueber-umsetzung-hinaus/observation.md)
(3 Belege).

**Ausdrücklich NICHT in diesem Slice:**

- **Der Bestand.** Geschlossene Pläne werden nicht umgeschrieben — das wäre rückwirkende Historie an
  Zeitdokumenten und ein eigener, größerer Schnitt.
- **Die Liefer-Punkte-Grenze.** Sie steht und bleibt bei drei; dieser Slice regelt die Herleitung
  **neben** ihr (Schicht-Abgrenzung).
- **Die Beweis-Pflicht selbst.** Kommando-Belege bleiben gefordert ([`MR-025`](../../../../harness/conventions.md#mr-025--eine-zahl-im-text-steht-neben-dem-kommando-das-sie-liefert));
  dieser Slice regelt, wie weit sie sich zum Gegenstand verhält.

## 2. Definition of Done

- [ ] Die zwei Zielorte nennen eine messbare Form — etwa die Zeilenzahl des Plans gegen die seiner
      Umsetzung —, statt nur ein Gefühl.
- [ ] Rot gesehen: ein Plan über der benannten Grenze färbt den Träger rot **oder** die Zusage ist
      auf das eingeschränkt, was der Lauf hält.
- [ ] `make gates` grün.
- [ ] Review durchgeführt, Report unter `docs/reviews/` liegt vor.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben.

## 3. Plan (vor Code)

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| Anweisungssatz [`plan-welle.md`](../../../../.claude/commands/plan-welle.md) bzw. `AGENTS.md` §3 | update | messbare Form und Grenze der Regel am Ort, den der schreibende Lauf liest |
| [`harness/tools/`](../../../../harness/tools) | neu | Träger, wenn die Zeilenzahl gemessen wird |
| [`test/`](../../../../test) | neu | Rot-Beleg über einem Plan über der Grenze |

## 4. Trigger

**Start** (`next` → `in-progress`): Priorisierung durch den Planner.

**Rückführungen:**

- `in-progress` → `next` (zu groß): wenn Regel und Messung zusammen kommen.
- `in-progress` → `open` (blockiert): wenn die Grenze ohne eine Gate-Senkung nicht erreichbar ist.

## 5. Closure-Trigger

DoD vollständig, Review ohne blockierenden Befund, Closure-Notiz geschrieben.

## 6. Risiken und offene Punkte

- Die Grenze ist ein Urteil und wird als Zahl ausgegeben — **Ausgang:** weiter offen →
  `BEO-ALL/stellen-messung-als-eigenschaft-ausgegeben` (unter der Schwelle).
- Die Regel greift nur für neue Pläne — **Ausgang:** weiter offen →
  `BEO-ALL/slice-plan-umfang-waechst-ueber-umsetzung-hinaus`.

## 7. Closure-Notiz

**Gegenstand:** übernommen von `slice-zusammenfassung-bleibt-innerhalb-ihrer-quelle`.

Stillgelegt ohne Lieferung (Baseline-Regelwerk `modul-05-planning-harness.md` §Ein Slice, dessen Gegenstand ein anderer übernimmt) im Bestands-Lese-Schritt der Welle-Closure `welle-emittiertes-doc-gate`, Auftraggeber-Entscheidung vom 2026-10-08. Die Liefer-Punkte der DoD bleiben leer.

- **Risiko-Ausgänge (§6):** jedes Risiko ohne vorab gesetzten Ausgang — *eingetreten* → `slice-zusammenfassung-bleibt-innerhalb-ihrer-quelle`, der den Gegenstand samt diesen Risiken führt; vorab gesetzte Ausgänge gelten unverändert.
- **Beobachtungs-Register:** `BEO-ALL/geplanter-slice-wird-nie-gearbeitet` — Beleg `welle-emittiertes-doc-gate`, eine Gelegenheit für alle Stilllegungen dieses Lese-Schritts.
- **Paarungen:** von der Welle-Closure `welle-emittiertes-doc-gate` geprüft, Ergebnis in deren Ergebnisnotiz.

- **Was hat funktioniert:** —
- **Was ging anders als geplant:** —
- **Steering-Loop-Eintrag:** —
- **Beobachtungs-Register (`../observations/`):** —
- **Folge-Slices:** —

## 8. Sub-Area-Prüfungen und Modus-Begründung

**Vorgelagert — Sub-Area-Wahl prüfen:** berührte Sub-Area `*`; Schwelle erfüllt.

**Vorgelagert — offene Beobachtungen sichten:** Treffer
[`BEO-ALL/slice-plan-umfang-waechst-ueber-umsetzung-hinaus`](../observations/BEO-ALL/slice-plan-umfang-waechst-ueber-umsetzung-hinaus/observation.md)
über der Schwelle.

**Modus-Begründungsblock — Umfang:** alle berührten Sub-Areas GF.
